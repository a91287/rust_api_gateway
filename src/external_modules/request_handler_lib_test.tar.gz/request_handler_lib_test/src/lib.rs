use hyper::{Body, Request, header::HeaderValue};
use log::info;

#[no_mangle]
pub extern "C" fn handle_request(mut req: Request<Body>) -> Request<Body> {
    // Add a header to the request
    //req.headers_mut().insert("X-Custom-Header", HeaderValue::from_static("CustomValue"));

    info!("Handling request in dynamic library");
    println!("Doing something");
    
    // Return the modified request
    req
}
